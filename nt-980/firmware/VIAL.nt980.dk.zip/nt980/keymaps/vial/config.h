/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0xDE, 0x64, 0x7D, 0x7D, 0xDF, 0x78, 0x48, 0xD8}
#define DYNAMIC_KEYMAP_LAYER_COUNT 3
#define VIAL_COMBO_ENTRIES 3
#define VIAL_TAP_DANCE_ENTRIES 4
#define NO_ACTION_MACRO
#define NO_ACTION_FUNCTION